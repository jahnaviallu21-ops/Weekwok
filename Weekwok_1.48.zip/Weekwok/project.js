/* ==========================================
   WEEKWOK — SMART MEAL & PANTRY PLANNER
========================================== */


/* ---------- RECIPE DATABASE ---------- */

const recipes = [
  {
    id: 1,
    name: "Paneer Butter Masala",
    category: "Dinner",
    time: 35,
    servings: 2,
    price: 180,
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800",
    description: "A rich, creamy paneer curry with tomatoes and aromatic spices.",
    ingredients: [
      { name: "Paneer", amount: 400, unit: "g" },
      { name: "Butter", amount: 50, unit: "g" },
      { name: "Tomatoes", amount: 250, unit: "g" },
      { name: "Cream", amount: 100, unit: "ml" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Heat butter and oil in a pan.",
      "Add chopped onions and cook until soft.",
      "Add tomatoes and spices. Cook until smooth.",
      "Add paneer cubes and cream.",
      "Simmer for 8–10 minutes and serve."
    ]
  },

  {
    id: 2,
    name: "Garden Harvest Bowl",
    category: "Lunch",
    time: 25,
    servings: 2,
    price: 120,
    image: "harvestgardenbowl.jpg",
    description: "A refreshing bowl filled with seasonal vegetables and greens.",
    ingredients: [
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Cucumber", amount: 150, unit: "g" },
      { name: "Spinach", amount: 100, unit: "g" },
      { name: "Olive Oil", amount: 15, unit: "ml" },
      { name: "Lemons", amount: 1, unit: "pcs" }
    ],
    instructions: [
      "Wash and prepare all vegetables.",
      "Chop the cucumber and tomatoes.",
      "Combine with fresh spinach.",
      "Prepare a lemon and olive oil dressing.",
      "Toss everything together and serve."
    ]
  },

  {
    id: 3,
    name: "Berry & Oat Bowl",
    category: "Breakfast",
    time: 10,
    servings: 2,
    price: 90,
    image: "berry&oatmeal.jpg",
    description: "A nourishing breakfast with oats, fresh fruit and yoghurt.",
    ingredients: [
      { name: "Rolled Oats", amount: 100, unit: "g" },
      { name: "Milk", amount: 250, unit: "ml" },
      { name: "Mixed Berries", amount: 100, unit: "g" },
      { name: "Honey", amount: 20, unit: "g" },
      { name: "Greek Yoghurt", amount: 100, unit: "g" }
    ],
    instructions: [
      "Cook oats with milk.",
      "Allow the oats to cool slightly.",
      "Add yoghurt and fresh berries.",
      "Drizzle with honey and serve."
    ]
  },

  {
    id: 4,
    name: "Avocado Sourdough",
    category: "Breakfast",
    time: 12,
    servings: 2,
    price: 110,
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800",
    description: "Crispy sourdough topped with creamy avocado.",
    ingredients: [
      { name: "Sourdough Bread", amount: 2, unit: "pcs" },
      { name: "Avocado", amount: 150, unit: "g" },
      { name: "Lemons", amount: 1, unit: "pcs" },
      { name: "Olive Oil", amount: 10, unit: "ml" }
    ],
    instructions: [
      "Toast the sourdough bread.",
      "Mash avocado with lemon juice.",
      "Spread the mixture over the toast.",
      "Finish with olive oil and seasoning."
    ]
  },

  {
    id: 5,
    name: "Tomato Basil Pasta",
    category: "Dinner",
    time: 25,
    servings: 2,
    price: 140,
    image: "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?w=800",
    description: "Classic pasta tossed in a fresh tomato and basil sauce.",
    ingredients: [
      { name: "Pasta", amount: 200, unit: "g" },
      { name: "Tomatoes", amount: 250, unit: "g" },
      { name: "Butter", amount: 20, unit: "g" },
      { name: "Onions", amount: 80, unit: "g" },
      { name: "Olive Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Boil pasta until cooked.",
      "Heat olive oil and butter.",
      "Add onions and tomatoes.",
      "Cook until the sauce thickens.",
      "Mix in pasta and serve."
    ]
  },

  {
    id: 6,
    name: "Golden Vegetable Curry",
    category: "Lunch",
    time: 40,
    servings: 2,
    price: 150,
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800",
    description: "A comforting vegetable curry with warming spices.",
    ingredients: [
      { name: "Potatoes", amount: 200, unit: "g" },
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 20, unit: "ml" },
      { name: "Spinach", amount: 80, unit: "g" }
    ],
    instructions: [
      "Heat oil in a pan.",
      "Add onions and tomatoes.",
      "Add chopped vegetables and spices.",
      "Add water and simmer until tender.",
      "Serve warm."
    ]
  },

  {
    id: 7,
    name: "Honey Fruit Pancakes",
    category: "Breakfast",
    time: 20,
    servings: 2,
    price: 100,
    image: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=800",
    description: "Soft pancakes topped with fresh fruits and honey.",
    ingredients: [
      { name: "Flour", amount: 150, unit: "g" },
      { name: "Milk", amount: 200, unit: "ml" },
      { name: "Eggs", amount: 2, unit: "pcs" },
      { name: "Honey", amount: 25, unit: "g" },
      { name: "Butter", amount: 20, unit: "g" }
    ],
    instructions: [
      "Combine flour, milk and eggs.",
      "Whisk until smooth.",
      "Cook small pancakes in a buttered pan.",
      "Top with fruits and honey."
    ]
  },

  {
    id: 8,
    name: "Homestyle Vegetable Pulao",
    category: "Lunch",
    time: 35,
    servings: 2,
    price: 130,
    image: "vegetablepulao.jpg",
    description: "Fragrant basmati rice cooked with fresh vegetables.",
    ingredients: [
      { name: "Basmati Rice", amount: 200, unit: "g" },
      { name: "Carrots", amount: 100, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" },
      { name: "Potatoes", amount: 100, unit: "g" }
    ],
    instructions: [
      "Wash and soak the rice.",
      "Heat oil and cook onions.",
      "Add vegetables and spices.",
      "Add rice and measured water.",
      "Cook until the rice is fluffy."
    ]
  },
  

  /* ---------- NEW BREAKFAST RECIPES ---------- */

  {
    id: 9,
    name: "Vegetable Poha",
    category: "Breakfast",
    time: 20,
    servings: 2,
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800",
    description: "Light and fluffy poha tossed with vegetables, peanuts and spices.",
    ingredients: [
      { name: "Poha", amount: 200, unit: "g" },
      { name: "Onions", amount: 80, unit: "g" },
      { name: "Potatoes", amount: 100, unit: "g" },
      { name: "Peanuts", amount: 30, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Rinse the poha gently and let it soften.",
      "Heat oil and add peanuts.",
      "Add onions and potatoes and cook until tender.",
      "Mix in the poha, turmeric and salt.",
      "Garnish with coriander and serve."
    ]
  },

  {
    id: 10,
    name: "French Toast",
    category: "Breakfast",
    time: 15,
    servings: 2,
    image: "french.jpg",
    description: "Golden bread slices dipped in a sweet egg and milk mixture.",
    ingredients: [
      { name: "Bread", amount: 4, unit: "pcs" },
      { name: "Eggs", amount: 2, unit: "pcs" },
      { name: "Milk", amount: 100, unit: "ml" },
      { name: "Butter", amount: 20, unit: "g" },
      { name: "Honey", amount: 20, unit: "g" }
    ],
    instructions: [
      "Whisk eggs, milk and honey together.",
      "Dip each bread slice into the mixture.",
      "Heat butter in a pan.",
      "Cook both sides until golden brown.",
      "Serve warm with fruit or honey."
    ]
  },

  {
    id: 11,
    name: "Banana Oat Pancakes",
    category: "Breakfast",
    time: 20,
    servings: 2,
    image: "https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=800",
    description: "Soft and wholesome pancakes made with bananas and oats.",
    ingredients: [
      { name: "Bananas", amount: 2, unit: "pcs" },
      { name: "Rolled Oats", amount: 100, unit: "g" },
      { name: "Milk", amount: 100, unit: "ml" },
      { name: "Eggs", amount: 1, unit: "pcs" },
      { name: "Butter", amount: 15, unit: "g" }
    ],
    instructions: [
      "Mash the bananas in a bowl.",
      "Add oats, milk and egg.",
      "Mix until combined.",
      "Heat butter in a pan.",
      "Cook small pancakes on both sides."
    ]
  },

  /* ---------- NEW LUNCH RECIPES ---------- */

  {
    id: 12,
    name: "Veg Fried Rice",
    category: "Lunch",
    time: 25,
    servings: 2,
    image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800",
    description: "Fluffy rice stir-fried with colourful vegetables and sauces.",
    ingredients: [
      { name: "Basmati Rice", amount: 200, unit: "g" },
      { name: "Carrots", amount: 80, unit: "g" },
      { name: "Capsicum", amount: 80, unit: "g" },
      { name: "Onions", amount: 60, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Cook the rice and allow it to cool.",
      "Heat oil in a wok.",
      "Add onions and chopped vegetables.",
      "Add cooked rice and seasonings.",
      "Toss well and serve hot."
    ]
  },

  {
    id: 13,
    name: "Chole Rice",
    category: "Lunch",
    time: 35,
    servings: 2,
    image: "chole.jpg",
    description: "Spiced chickpea curry served with fragrant rice.",
    ingredients: [
      { name: "Chickpeas", amount: 200, unit: "g" },
      { name: "Basmati Rice", amount: 150, unit: "g" },
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Soak chickpeas overnight and pressure cook.",
      "Cook onions and tomatoes with spices.",
      "Add chickpeas and simmer.",
      "Cook rice separately.",
      "Serve the chole with warm rice."
    ]
  },

  {
    id: 14,
    name: "Spinach Corn Rice",
    category: "Lunch",
    time: 30,
    servings: 2,
    image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800",
    description: "A delicious rice dish with spinach, sweet corn and mild spices.",
    ingredients: [
      { name: "Basmati Rice", amount: 180, unit: "g" },
      { name: "Spinach", amount: 120, unit: "g" },
      { name: "Sweet Corn", amount: 100, unit: "g" },
      { name: "Onions", amount: 60, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Cook the rice and keep aside.",
      "Heat oil and sauté onions.",
      "Add spinach and sweet corn.",
      "Season and cook until tender.",
      "Mix in the rice and serve."
    ]
  },

  {
    id: 15,
    name: "Rajma Chawal",
    category: "Lunch",
    time: 40,
    servings: 2,
    image: "https://images.unsplash.com/photo-1547592180-85f173990554?w=800",
    description: "Comforting kidney bean curry served with steamed rice.",
    ingredients: [
      { name: "Kidney Beans", amount: 200, unit: "g" },
      { name: "Basmati Rice", amount: 150, unit: "g" },
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Soak kidney beans overnight.",
      "Pressure cook until soft.",
      "Prepare a gravy with onions and tomatoes.",
      "Add kidney beans and simmer.",
      "Serve with steamed rice."
    ]
  },

  /* ---------- NEW DINNER RECIPES ---------- */

  {
    id: 16,
    name: "Palak Paneer",
    category: "Dinner",
    time: 30,
    servings: 2,
    image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=800",
    description: "Soft paneer cubes in a creamy and flavourful spinach gravy.",
    ingredients: [
      { name: "Paneer", amount: 200, unit: "g" },
      { name: "Spinach", amount: 250, unit: "g" },
      { name: "Onions", amount: 80, unit: "g" },
      { name: "Tomatoes", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Blanch spinach and blend into a smooth paste.",
      "Heat oil and sauté onions.",
      "Add tomatoes and spices.",
      "Mix in the spinach puree.",
      "Add paneer cubes and simmer."
    ]
  },

  {
    id: 17,
    name: "Vegetable Korma",
    category: "Dinner",
    time: 35,
    servings: 2,
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800",
    description: "Mixed vegetables cooked in a rich and mildly spiced gravy.",
    ingredients: [
      { name: "Carrots", amount: 100, unit: "g" },
      { name: "Potatoes", amount: 150, unit: "g" },
      { name: "Green Peas", amount: 80, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cream", amount: 50, unit: "ml" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Chop all vegetables.",
      "Sauté onions in oil.",
      "Add vegetables and spices.",
      "Add water and cook until tender.",
      "Stir in cream and serve."
    ]
  },

  {
    id: 18,
    name: "Dal Tadka",
    category: "Dinner",
    time: 30,
    servings: 2,
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800",
    description: "Yellow lentils finished with a fragrant garlic and spice tempering.",
    ingredients: [
      { name: "Toor Dal", amount: 150, unit: "g" },
      { name: "Tomatoes", amount: 100, unit: "g" },
      { name: "Onions", amount: 80, unit: "g" },
      { name: "Butter", amount: 15, unit: "g" },
      { name: "Cooking Oil", amount: 10, unit: "ml" }
    ],
    instructions: [
      "Wash and pressure cook the dal.",
      "Sauté onions and tomatoes.",
      "Add spices and cooked dal.",
      "Prepare a tempering with butter and garlic.",
      "Pour over the dal and serve."
    ]
  },

  {
    id: 19,
    name: "Mushroom Masala",
    category: "Dinner",
    time: 30,
    servings: 2,
    image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800",
    description: "Tender mushrooms cooked in a rich onion and tomato masala.",
    ingredients: [
      { name: "Mushrooms", amount: 200, unit: "g" },
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cream", amount: 40, unit: "ml" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Clean and slice the mushrooms.",
      "Sauté onions in oil.",
      "Add tomatoes and spices.",
      "Add mushrooms and cook until tender.",
      "Finish with cream and serve."
    ]
  },

  /* ---------- NEW SNACK RECIPES ---------- */

  {
    id: 20,
    name: "Paneer Sandwich",
    category: "Snacks",
    time: 15,
    servings: 2,
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800",
    description: "Toasted bread filled with a tasty spiced paneer mixture.",
    ingredients: [
      { name: "Paneer", amount: 150, unit: "g" },
      { name: "Bread", amount: 4, unit: "pcs" },
      { name: "Onions", amount: 40, unit: "g" },
      { name: "Capsicum", amount: 40, unit: "g" },
      { name: "Butter", amount: 15, unit: "g" }
    ],
    instructions: [
      "Crumble paneer and mix with chopped vegetables.",
      "Add salt and spices.",
      "Spread the mixture between bread slices.",
      "Toast with butter until golden.",
      "Cut and serve."
    ]
  },

  {
    id: 21,
    name: "Aloo Tikki",
    category: "Snacks",
    time: 25,
    servings: 2,
    image: "https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?w=800",
    description: "Crispy golden potato patties seasoned with Indian spices.",
    ingredients: [
      { name: "Potatoes", amount: 300, unit: "g" },
      { name: "Green Peas", amount: 50, unit: "g" },
      { name: "Corn Flour", amount: 20, unit: "g" },
      { name: "Cooking Oil", amount: 20, unit: "ml" }
    ],
    instructions: [
      "Boil and mash the potatoes.",
      "Mix in peas, corn flour and spices.",
      "Shape into small patties.",
      "Shallow fry until crisp on both sides.",
      "Serve with chutney."
    ]
  },

  {
    id: 22,
    name: "Vegetable Cutlets",
    category: "Snacks",
    time: 30,
    servings: 2,
    image: "https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?w=800",
    description: "Crunchy vegetable patties made with potatoes and mixed vegetables.",
    ingredients: [
      { name: "Potatoes", amount: 200, unit: "g" },
      { name: "Carrots", amount: 80, unit: "g" },
      { name: "Green Peas", amount: 60, unit: "g" },
      { name: "Bread Crumbs", amount: 50, unit: "g" },
      { name: "Cooking Oil", amount: 20, unit: "ml" }
    ],
    instructions: [
      "Boil and mash the vegetables.",
      "Mix with breadcrumbs and spices.",
      "Shape into cutlets.",
      "Coat with breadcrumbs.",
      "Shallow fry until golden and crisp."
    ]
  },

  {
    id: 23,
    name: "Masala Corn",
    category: "Snacks",
    time: 10,
    servings: 2,
    image: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=800",
    description: "Sweet corn tossed with butter, lemon and tangy spices.",
    ingredients: [
      { name: "Sweet Corn", amount: 200, unit: "g" },
      { name: "Butter", amount: 15, unit: "g" },
      { name: "Lemons", amount: 1, unit: "pcs" }
    ],
    instructions: [
      "Boil the sweet corn until tender.",
      "Drain the water.",
      "Add butter, salt and spices.",
      "Squeeze lemon juice over the corn.",
      "Mix well and serve warm."
    ]
  }

];


/* ---------- INITIAL DATA ---------- */

const defaultPantry = [
  { id: 1, name: "Paneer", quantity: 200, unit: "g", expiry: "", price: 0.45 },
  { id: 2, name: "Basmati Rice", quantity: 1000, unit: "g", expiry: "", price: 0.12 },
  { id: 3, name: "Cooking Oil", quantity: 1000, unit: "ml", expiry: "", price: 0.18 },
  { id: 4, name: "Onions", quantity: 500, unit: "g", expiry: "", price: 0.08 },
  { id: 5, name: "Eggs", quantity: 6, unit: "pcs", expiry: "", price: 7 },
  { id: 6, name: "Tomatoes", quantity: 300, unit: "g", expiry: "", price: 0.08 },
  { id: 7, name: "Milk", quantity: 500, unit: "ml", expiry: "", price: 0.07 }
];

const days = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
];

const slots = ["Breakfast", "Lunch", "Dinner"];

let pantry = load("weekwok-pantry", defaultPantry);
let plan = load("weekwok-plan", {});
let completed = load("weekwok-completed", []);
let checkedShopping = load("weekwok-checked", []);
let activeRecipe = null;
let servingCount = 2;
let toastTimer;


/* ---------- STORAGE ---------- */

function load(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : structuredClone(fallback);
  } catch {
    return structuredClone(fallback);
  }
}

function saveAll() {
  localStorage.setItem("weekwok-pantry", JSON.stringify(pantry));
  localStorage.setItem("weekwok-plan", JSON.stringify(plan));
  localStorage.setItem("weekwok-completed", JSON.stringify(completed));
  localStorage.setItem("weekwok-checked", JSON.stringify(checkedShopping));
}


/* ---------- HELPERS ---------- */

function normalName(name) {
  return name.trim().toLowerCase();
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function keyFor(day, slot) {
  return `${day}-${slot}`;
}

function showToast(message) {
  const toast = document.getElementById("toast");

  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2800);
}

function recipeById(id) {
  return recipes.find(recipe => recipe.id === Number(id));
}

function convertToBase(amount, unit) {
  if (unit === "kg") return { amount: amount * 1000, unit: "g" };
  if (unit === "l") return { amount: amount * 1000, unit: "ml" };

  return { amount, unit };
}

function formatQuantity(amount, unit) {
  const rounded = Math.round(amount * 100) / 100;

  if (unit === "g" && rounded >= 1000) {
    return `${rounded / 1000} kg`;
  }

  if (unit === "ml" && rounded >= 1000) {
    return `${rounded / 1000} L`;
  }

  return `${rounded} ${unit}`;
}

function ingredientQuantity(recipe, ingredient, servings) {
  return ingredient.amount * servings / recipe.servings;
}


/* ---------- PAGE NAVIGATION ---------- */

function showPage(page) {
  document.querySelectorAll(".page").forEach(section => {
    section.classList.toggle("active", section.id === page);
  });

  document.querySelectorAll(".nav-link").forEach(button => {
    button.classList.toggle("active", button.dataset.page === page);
  });

  history.replaceState(null, "", `#${page}`);

  if (page === "planner") renderPlanner();
  if (page === "pantry") renderPantry();
  if (page === "shopping") renderShopping();
  if (page === "home") renderHome();
}

document.querySelectorAll("[data-page]").forEach(button => {
  button.addEventListener("click", () => showPage(button.dataset.page));
});

document.querySelectorAll("[data-go]").forEach(button => {
  button.addEventListener("click", () => showPage(button.dataset.go));
});

/* ---------- PANTRY RESERVATION ENGINE ---------- */

function getReservations(excludeKey = null) {
    const reservations = {};

    Object.entries(plan).forEach(([key, recipeId]) => {
        if (!recipeId || completed.includes(key) || key === excludeKey) return;

        const recipe = recipeById(recipeId);
        if (!recipe) return;

        recipe.ingredients.forEach(ingredient => {
            const name = normalName(ingredient.name);
            const base = convertToBase(ingredient.amount, ingredient.unit);

            if (!reservations[name]) {
                reservations[name] = {
                    name: ingredient.name,
                    amount: 0,
                    unit: base.unit
                };
            }

            if (reservations[name].unit === base.unit) {
                reservations[name].amount += base.amount;
            }
        });
    });

    return reservations;
}


function getPantryAvailability() {
    const reservations = getReservations();
    const availability = {};

    pantry.forEach(item => {
        const base = convertToBase(item.quantity, item.unit);
        const name = normalName(item.name);

        const reserved =
            reservations[name]?.unit === base.unit
                ? reservations[name].amount
                : 0;

        availability[name] = {
            stock: base.amount,
            reserved: reserved,
            available: Math.max(0, base.amount - reserved),
            unit: base.unit
        };
    });

    return availability;
}

/* ---------- GROCERY CALCULATOR ---------- */

function getShoppingItems() {
    const requirements = {};

    // Calculate total ingredients required by all planned meals
    Object.entries(plan).forEach(([key, recipeId]) => {
        if (!recipeId || completed.includes(key)) return;

        const recipe = recipeById(recipeId);
        if (!recipe) return;

        recipe.ingredients.forEach(ingredient => {
            const name = normalName(ingredient.name);
            const base = convertToBase(
                ingredient.amount,
                ingredient.unit
            );

            if (!requirements[name]) {
                requirements[name] = {
                    name: ingredient.name,
                    amount: 0,
                    unit: base.unit
                };
            }

            if (requirements[name].unit === base.unit) {
                requirements[name].amount += base.amount;
            }
        });
    });

    const shoppingItems = [];

    // Compare total requirements against actual pantry stock
    Object.values(requirements).forEach(required => {
        const pantryItem = pantry.find(
            item => normalName(item.name) === normalName(required.name)
        );

        let availableStock = 0;

        if (pantryItem) {
            const base = convertToBase(
                pantryItem.quantity,
                pantryItem.unit
            );

            if (base.unit === required.unit) {
                availableStock = base.amount;
            }
        }

        const missing = Math.max(
            0,
            required.amount - availableStock
        );

        if (missing > 0) {
            shoppingItems.push({
                name: required.name,
                 amount: missing,
                unit: required.unit,
                price: pantryItem?.price || 0.15
            });
        }
    });

    return shoppingItems;
}

/* ---------- MEAL PLANNER ---------- */

function renderPlanner() {
  const container = document.getElementById("days-list");

  container.innerHTML = days.map((day, dayIndex) => {

    const date = 16 + dayIndex;

    return `
      <article class="day-row">

        <div class="day-date">
          <small>${day.toUpperCase()}</small>
          <strong>${date}</strong>
        </div>

        ${slots.map((slot, slotIndex) => {

          const key = keyFor(dayIndex, slotIndex);
          const recipe = recipeById(plan[key]);
          const isCompleted = completed.includes(key);

          if (!recipe) {
            return `
              <div class="meal-slot empty"
                   data-day="${dayIndex}"
                   data-slot="${slotIndex}">
                + Add ${slot}
              </div>
            `;
          }

          return `
            <div class="meal-slot"
                 data-day="${dayIndex}"
                 data-slot="${slotIndex}">

              <img src="${recipe.image}" alt="${escapeHTML(recipe.name)}">

              <div class="meal-slot-content">
                <small>${slot.toUpperCase()}</small>
                <strong>${escapeHTML(recipe.name)}</strong>
                <span>◷ ${recipe.time} min</span>
                ${isCompleted ? '<p class="completed-badge">✓ COMPLETED</p>' : ''}
              </div>

              <div class="slot-actions">
                <button data-view-recipe="${recipe.id}">View recipe</button>
                <button data-remove="${key}">Remove</button>
                ${!isCompleted ? `<button data-complete="${key}">Complete</button>` : ''}
              </div>

            </div>
          `;

        }).join("")}

      </article>
    `;
  }).join("");
}

document.getElementById("days-list").addEventListener("click", event => {

  const remove = event.target.closest("[data-remove]");
  const complete = event.target.closest("[data-complete]");
  const view = event.target.closest("[data-view-recipe]");
  const slot = event.target.closest(".meal-slot");

  if (remove) {
    const key = remove.dataset.remove;

    delete plan[key];
    completed = completed.filter(item => item !== key);

    saveAll();
    refreshEverything();

    showToast("Meal removed. Pantry reservations released.");
    return;
  }

  if (complete) {
    completeMeal(complete.dataset.complete);
    return;
  }

  if (view) {
    openRecipe(Number(view.dataset.viewRecipe));
    return;
  }

  if (slot) {
    openAssignModal(
      Number(slot.dataset.day),
      Number(slot.dataset.slot)
    );
  }
});


/* ---------- MEAL COMPLETION ---------- */

function completeMeal(key) {
    const recipeId = plan[key];
    const recipe = recipeById(recipeId);

    if (!recipe) return;

    // Exclude this meal's own reservation
    const reservations = getReservations(key);

    // Check whether enough pantry stock is available
    const missingIngredients = [];

    recipe.ingredients.forEach(ingredient => {
        const name = normalName(ingredient.name);
        const base = convertToBase(ingredient.amount, ingredient.unit);

        const pantryItem = pantry.find(
            item => normalName(item.name) === name
        );

        if (!pantryItem) {
            missingIngredients.push(ingredient.name);
            return;
        }

        const stock = convertToBase(
            pantryItem.quantity,
            pantryItem.unit
        );

        const reservedByOthers =
            reservations[name]?.unit === stock.unit
                ? reservations[name].amount
                : 0;

        const available = Math.max(
            0,
            stock.amount - reservedByOthers
        );

        if (stock.unit !== base.unit || available < base.amount) {
            missingIngredients.push(ingredient.name);
        }
    });

    if (missingIngredients.length > 0) {
        showToast(
            `Not enough ingredients: ${missingIngredients.join(", ")}`,
            "error"
        );
        return;
    }

    // Deduct ingredients from pantry
    recipe.ingredients.forEach(ingredient => {
        const name = normalName(ingredient.name);
        const base = convertToBase(ingredient.amount, ingredient.unit);

        const pantryItem = pantry.find(
            item => normalName(item.name) === name
        );

        if (!pantryItem) return;

        const stock = convertToBase(
            pantryItem.quantity,
            pantryItem.unit
        );

        pantryItem.quantity = Math.max(
            0,
            stock.amount - base.amount
        );

        pantryItem.unit = stock.unit;
    });

    completed.push(key);

    refreshEverything();

    showToast(`${recipe.name} completed! Pantry updated.`, "success");
}


/* ---------- DRAG AND DROP ---------- */

let draggedRecipeId = null;

document.addEventListener("dragstart", event => {
  const card = event.target.closest("[data-recipe-card]");

  if (card) {
    draggedRecipeId = Number(card.dataset.recipeCard);

    event.dataTransfer.setData("text/plain", draggedRecipeId);
    event.dataTransfer.effectAllowed = "copy";
  }
});

document.addEventListener("dragover", event => {
  const slot = event.target.closest(".meal-slot");

  if (slot) {
    event.preventDefault();
    slot.classList.add("drag-over");
  }
});

document.addEventListener("dragleave", event => {
  const slot = event.target.closest(".meal-slot");

  if (slot) slot.classList.remove("drag-over");
});

document.addEventListener("drop", event => {
  const slot = event.target.closest(".meal-slot");

  if (!slot) return;

  event.preventDefault();

  slot.classList.remove("drag-over");

  const id = Number(event.dataTransfer.getData("text/plain")) || draggedRecipeId;

  if (!id) return;

  assignRecipe(
    Number(slot.dataset.day),
    Number(slot.dataset.slot),
    id
  );

  draggedRecipeId = null;
});


/* ---------- ASSIGNMENT MODAL ---------- */

function openAssignModal(day = 0, slot = 0) {
  const recipeSelect = document.getElementById("assign-recipe");
  const daySelect = document.getElementById("assign-day");

  recipeSelect.innerHTML = recipes.map(recipe => `
    <option value="${recipe.id}">${escapeHTML(recipe.name)}</option>
  `).join("");

  daySelect.innerHTML = days.map((name, index) => `
    <option value="${index}" ${index === day ? "selected" : ""}>
      ${name}
    </option>
  `).join("");

  document.getElementById("assign-slot").value = slot;

  document.getElementById("assign-modal").classList.add("open");
}

document.getElementById("confirm-assignment").addEventListener("click", () => {
  const recipeId = Number(document.getElementById("assign-recipe").value);
  const day = Number(document.getElementById("assign-day").value);
  const slot = Number(document.getElementById("assign-slot").value);

  assignRecipe(day, slot, recipeId);

  document.getElementById("assign-modal").classList.remove("open");
});

function assignRecipe(day, slot, recipeId) {
  const key = keyFor(day, slot);

  plan[key] = Number(recipeId);
  completed = completed.filter(item => item !== key);

  saveAll();
  refreshEverything();

  const missing = getShoppingItems();

  showToast("Meal added! Pantry and shopping list updated.");

  if (missing.length) {
    setTimeout(() => {
      showToast("Some ingredients are missing. Check your shopping list.");
    }, 1800);
  }
}


/* ---------- RECIPE CATALOG ---------- */

function renderRecipes() {
  const search = normalName(document.getElementById("recipe-search").value);
  const category = document.getElementById("recipe-filter").value;

  const filtered = recipes.filter(recipe => {
    return (
      normalName(recipe.name).includes(search) &&
      (category === "all" || recipe.category === category)
    );
  });

  document.getElementById("recipe-grid").innerHTML =
    filtered.map(recipe => `
      <article class="recipe-card"
               draggable="true"
               data-recipe-card="${recipe.id}"
               data-open-recipe="${recipe.id}">

        <img src="${recipe.image}" alt="${escapeHTML(recipe.name)}">

        <div class="recipe-card-info">
          <small>${recipe.category.toUpperCase()}</small>

          <h3>${escapeHTML(recipe.name)}</h3>

          <p>${escapeHTML(recipe.description)}</p>

          <div class="recipe-meta">
            <span>◷ ${recipe.time} MIN</span>
            <span>${recipe.servings} SERVINGS</span>
          </div>
        </div>

      </article>
    `).join("") || '<p class="empty-note">No recipes found.</p>';
}

document.getElementById("recipe-search").addEventListener("input", renderRecipes);
document.getElementById("recipe-filter").addEventListener("change", renderRecipes);

document.getElementById("recipe-grid").addEventListener("click", event => {
  const card = event.target.closest("[data-open-recipe]");

  if (card) openRecipe(Number(card.dataset.openRecipe));
});


/* ---------- RECIPE POP-UP ---------- */

function openRecipe(id) {
  activeRecipe = recipeById(id);

  if (!activeRecipe) return;

  servingCount = activeRecipe.servings;

  renderRecipeDetails();

  document.getElementById("recipe-modal").classList.add("open");
}

function renderRecipeDetails() {
  const recipe = activeRecipe;

  const ingredients = recipe.ingredients.map(ingredient => {
    const quantity = ingredientQuantity(recipe, ingredient, servingCount);

    const pantryItem = pantry.find(
      item => normalName(item.name) === normalName(ingredient.name)
    );

    const available = pantryItem
      ? convertToBase(pantryItem.quantity, pantryItem.unit)
      : { amount: 0, unit: ingredient.unit };

    const needed = convertToBase(quantity, ingredient.unit);

    const stockAvailable = available.unit === needed.unit
      ? available.amount
      : 0;

    const missing = Math.max(0, needed.amount - stockAvailable);

    return `
      <div class="ingredient-row">
        <span>${escapeHTML(ingredient.name)}</span>
        <small>
          ${formatQuantity(quantity, ingredient.unit)}
          ${missing > 0 ? ` · Need ${formatQuantity(missing, ingredient.unit)} more` : ' · In pantry'}
        </small>
      </div>
    `;
  }).join("");

  document.getElementById("recipe-details").innerHTML = `
    <div class="recipe-detail-layout">

      <img class="recipe-detail-image"
           src="${recipe.image}"
           alt="${escapeHTML(recipe.name)}">

      <div class="recipe-detail-content">

        <span class="eyebrow">${recipe.category.toUpperCase()} · WEEKWOK COLLECTION</span>

        <h2>${escapeHTML(recipe.name)}</h2>

        <p>${escapeHTML(recipe.description)}</p>

        <div class="detail-meta">
          <span>◷ ${recipe.time} min</span>
          <span>₹${recipe.price} approx.</span>
        </div>

        <div class="serving-row">
          <span>Servings</span>
          <button id="serving-minus">−</button>
          <strong>${servingCount}</strong>
          <button id="serving-plus">+</button>
        </div>

        <h3>Ingredients</h3>

        ${ingredients}

        <h3>Preparation</h3>

        <ol class="instructions">
          ${recipe.instructions.map(step => `<li>${escapeHTML(step)}</li>`).join("")}
        </ol>

        <div class="recipe-detail-actions">
          <button class="primary-btn" id="recipe-add-plan">
            Add to meal plan
          </button>

          <button class="outline-btn" id="recipe-close">
            Close
          </button>
        </div>

      </div>

    </div>
  `;

  document.getElementById("serving-minus").addEventListener("click", () => {
    if (servingCount > 1) {
      servingCount--;
      renderRecipeDetails();
    }
  });

  document.getElementById("serving-plus").addEventListener("click", () => {
    if (servingCount < 20) {
      servingCount++;
      renderRecipeDetails();
    }
  });

  document.getElementById("recipe-add-plan").addEventListener("click", () => {
    document.getElementById("recipe-modal").classList.remove("open");

    document.getElementById("assign-recipe").innerHTML = `
      <option value="${recipe.id}">${escapeHTML(recipe.name)}</option>
    `;

    openAssignModal();
    document.getElementById("assign-recipe").value = recipe.id;
  });

  document.getElementById("recipe-close").addEventListener("click", () => {
    document.getElementById("recipe-modal").classList.remove("open");
  });
}


/* ---------- PANTRY ---------- */

function renderPantry() {
  const availability = getPantryAvailability();

  const total = pantry.length;

  const lowStock = pantry.filter(item => {
    const name = normalName(item.name);
    const available = availability[name]?.available || 0;
    return available < 100 && item.unit !== "pcs";
  }).length;

  document.getElementById("pantry-summary").innerHTML = `
    <div><strong>${total}</strong><small>Ingredients tracked</small></div>
    <div><strong>${lowStock}</strong><small>Low-stock items</small></div>
    <div><strong>${getExpiringItems().length}</strong><small>Expiring soon</small></div>
  `;

  document.getElementById("pantry-body").innerHTML =
    pantry.map(item => {
      const name = normalName(item.name);
      const data = availability[name] || {
        reserved: 0,
        available: item.quantity
      };

      const base = convertToBase(item.quantity, item.unit);

      const expiry = item.expiry
        ? new Date(item.expiry + "T00:00:00")
        : null;

      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const daysLeft = expiry
        ? Math.ceil((expiry - today) / 86400000)
        : null;

      let status = "In stock";
      let statusClass = "";

      if (daysLeft !== null && daysLeft < 0) {
        status = "Expired";
        statusClass = "expiring";
      } else if (daysLeft !== null && daysLeft <= 3) {
        status = "Expiring soon";
        statusClass = "expiring";
      } else if (data.available <= 0) {
        status = "Reserved";
        statusClass = "low";
      } else if (data.available < 100 && base.unit !== "pcs") {
        status = "Low stock";
        statusClass = "low";
      }

      return `
        <tr>
          <td><strong>${escapeHTML(item.name)}</strong></td>
          <td>${formatQuantity(base.amount, base.unit)}</td>
          <td>${formatQuantity(data.reserved, base.unit)}</td>
          <td>${formatQuantity(data.available, base.unit)}</td>
          <td>${item.expiry || "—"}</td>
          <td><span class="status ${statusClass}">${status}</span></td>
          <td><button class="table-action" data-delete-pantry="${item.id}">Remove</button></td>
        </tr>
      `;
    }).join("");

  renderPantryAlerts();
}

function getExpiringItems() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return pantry.filter(item => {
    if (!item.expiry) return false;

    const expiry = new Date(item.expiry + "T00:00:00");
    const difference = Math.ceil((expiry - today) / 86400000);

    return difference >= 0 && difference <= 3;
  });
}

function renderPantryAlerts() {
  const alerts = [];

  pantry.forEach(item => {
    const expiry = item.expiry
      ? new Date(item.expiry + "T00:00:00")
      : null;

    if (!expiry) return;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const difference = Math.ceil((expiry - today) / 86400000);

    if (difference >= 0 && difference <= 3) {
      alerts.push(`
        <div class="alert-box warning">
          ⚠ ${escapeHTML(item.name)} expires ${difference === 0 ? "today" : `in ${difference} day(s)`}.
        </div>
      `);
    }

    if (difference < 0) {
      alerts.push(`
        <div class="alert-box warning">
          ⚠ ${escapeHTML(item.name)} has expired. Check this ingredient before using it.
        </div>
      `);
    }
  });

  document.getElementById("pantry-alerts").innerHTML =
    alerts.join("") || '<div class="alert-box">✳ Your pantry has no upcoming expiry alerts.</div>';
}

document.getElementById("open-pantry-form").addEventListener("click", () => {
  document.getElementById("pantry-modal").classList.add("open");
});

document.getElementById("pantry-form").addEventListener("submit", event => {
  event.preventDefault();

  const name = document.getElementById("ingredient-name").value.trim();
  const quantity = Number(document.getElementById("ingredient-quantity").value);
  const unit = document.getElementById("ingredient-unit").value;
  const expiry = document.getElementById("ingredient-expiry").value;
  const price = Number(document.getElementById("ingredient-price").value) || 0;

  if (!name || quantity <= 0) {
    showToast("Enter a valid ingredient and quantity.");
    return;
  }

  const existing = pantry.find(item => normalName(item.name) === normalName(name));

  const base = convertToBase(quantity, unit);

  if (existing) {
    const existingBase = convertToBase(existing.quantity, existing.unit);

    if (existingBase.unit !== base.unit) {
      showToast("This ingredient has an incompatible unit.");
      return;
    }

    existing.quantity = existingBase.amount + base.amount;
    existing.unit = base.unit;

    if (expiry) existing.expiry = expiry;
    if (price) existing.price = price;
  } else {
    pantry.push({
      id: Date.now(),
      name,
      quantity: base.amount,
      unit: base.unit,
      expiry,
      price
    });
  }

  saveAll();
  event.target.reset();

  document.getElementById("pantry-modal").classList.remove("open");

  refreshEverything();
  showToast(`${name} added to your pantry.`);
});

document.getElementById("pantry-body").addEventListener("click", event => {
  const button = event.target.closest("[data-delete-pantry]");

  if (!button) return;

  const id = Number(button.dataset.deletePantry);
  const item = pantry.find(entry => entry.id === id);

  if (!item) return;

  if (!confirm(`Remove ${item.name} from your pantry?`)) return;

  pantry = pantry.filter(entry => entry.id !== id);

  saveAll();
  refreshEverything();

  showToast("Ingredient removed.");
});


/* ---------- SHOPPING LIST ---------- */

function renderShopping() {
  const items = getShoppingItems();

  const categories = {
    "Fresh Produce": ["tomato", "onion", "spinach", "potato", "cucumber", "carrot", "lemon", "avocado"],
    "Dairy & Protein": ["paneer", "milk", "cream", "egg", "yoghurt"],
    "Pantry Staples": ["rice", "pasta", "oat", "flour", "oil", "butter", "honey", "chickpea", "bread"],
    "Other Essentials": []
  };

  const grouped = {};

  items.forEach(item => {
    let category = "Other Essentials";

    for (const [group, words] of Object.entries(categories)) {
      if (group === "Other Essentials") continue;

      if (words.some(word => normalName(item.name).includes(word))) {
        category = group;
        break;
      }
    }

    if (!grouped[category]) grouped[category] = [];

    grouped[category].push(item);
  });

  const list = document.getElementById("shopping-list");

  list.innerHTML = Object.entries(grouped).map(([category, entries]) => `
    <section class="shopping-category">

      <h3>${category}</h3>
      <small>YOUR WEEKLY ESSENTIALS</small>

      ${entries.map(item => {
        const key = normalName(item.name);
        const isChecked = checkedShopping.includes(key);

        return `
          <div class="shopping-item ${isChecked ? "checked" : ""}">
            <label>
              <input type="checkbox"
                     data-shopping="${escapeHTML(key)}"
                     ${isChecked ? "checked" : ""}>
              <span>${escapeHTML(item.name)}</span>
            </label>

            <small>${formatQuantity(item.amount, item.unit)}</small>
          </div>
        `;
      }).join("")}

    </section>
  `).join("") || `
    <div class="shopping-category">
      <h3>Nothing missing.</h3>
      <p>Your scheduled meals are covered by your pantry stock. Lovely work!</p>
    </div>
  `;

  const estimatedCost = items.reduce((total, item) => {
    return total + item.amount * item.price;
  }, 0);

  const done = items.filter(item =>
    checkedShopping.includes(normalName(item.name))
  ).length;

  document.getElementById("shopping-cost").textContent =
    `₹${Math.round(estimatedCost)}`;

  document.getElementById("shopping-count").textContent =
    `${done} / ${items.length}`;

  document.getElementById("shopping-progress-bar").style.width =
    `${items.length ? done / items.length * 100 : 0}%`;

  document.getElementById("shopping-message").textContent =
    items.length
      ? `${items.length - done} ingredients still to pick up.`
      : "Your pantry has everything your planned meals need.";
}

document.getElementById("shopping-list").addEventListener("change", event => {
  const checkbox = event.target;

  if (!checkbox.matches("[data-shopping]")) return;

  const name = checkbox.dataset.shopping;

  if (checkbox.checked) {
    if (!checkedShopping.includes(name)) checkedShopping.push(name);
  } else {
    checkedShopping = checkedShopping.filter(item => item !== name);
  }

  saveAll();
  renderShopping();
});


/* ---------- WHATSAPP EXPORT ---------- */

document.getElementById("whatsapp-btn").addEventListener("click", () => {
  const items = getShoppingItems();

  if (!items.length) {
    showToast("Your shopping list is empty.");
    return;
  }

  let message = "🛒 *MY WEEKWOK SHOPPING LIST*\n\n";

  items.forEach(item => {
    const checked = checkedShopping.includes(normalName(item.name));

    message += `${checked ? "✅" : "☐"} ${item.name} — ${formatQuantity(item.amount, item.unit)}\n`;
  });

  message += "\n🌿 Planned with WeekWok.";

  const url = `https://wa.me/?text=${encodeURIComponent(message)}`;

  window.open(url, "_blank");
});


/* ---------- HOME DASHBOARD ---------- */

function renderHome() {
  const mealCount = Object.keys(plan).filter(key => plan[key]).length;

  document.getElementById("stat-meals").textContent = mealCount;
  document.getElementById("stat-pantry").textContent = pantry.length;
  document.getElementById("stat-shopping").textContent = getShoppingItems().length;
  document.getElementById("stat-expiring").textContent = getExpiringItems().length;

  const container = document.getElementById("home-meals");

  const planned = Object.entries(plan)
    .filter(([key, id]) => id)
    .slice(0, 4);

  container.innerHTML = planned.map(([key, id]) => {
    const recipe = recipeById(id);

    if (!recipe) return "";

    const [dayIndex, slotIndex] = key.split("-").map(Number);

    return `
      <article class="home-meal-card" data-home-recipe="${recipe.id}">
        <img src="${recipe.image}" alt="${escapeHTML(recipe.name)}">

        <div>
          <small>${days[dayIndex].toUpperCase()} · ${slots[slotIndex].toUpperCase()}</small>
          <h3>${escapeHTML(recipe.name)}</h3>
          <p>◷ ${recipe.time} minutes</p>
        </div>
      </article>
    `;
  }).join("") || `
    <div class="home-meal-card">
      <div>
        <small>YOUR WEEK IS WAITING</small>
        <h3>No meals planned yet.</h3>
        <p>Start by adding a recipe to your calendar.</p>
      </div>
    </div>
  `;
}

document.getElementById("home-meals").addEventListener("click", event => {
  const card = event.target.closest("[data-home-recipe]");

  if (card) openRecipe(Number(card.dataset.homeRecipe));
});


/* ---------- MODAL CONTROLS ---------- */

document.querySelectorAll("[data-close]").forEach(button => {
  button.addEventListener("click", () => {
    button.closest(".modal-overlay").classList.remove("open");
  });
});

document.querySelectorAll(".modal-overlay").forEach(overlay => {
  overlay.addEventListener("click", event => {
    if (event.target === overlay) {
      overlay.classList.remove("open");
    }
  });
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape") {
    document.querySelectorAll(".modal-overlay").forEach(modal => {
      modal.classList.remove("open");
    });
  }
});


/* ---------- REFRESH ---------- */

function refreshEverything() {
  saveAll();

  renderPlanner();
  renderPantry();
  renderShopping();
  renderHome();
  renderRecipes();
}


/* ---------- START APPLICATION ---------- */

document.getElementById("current-date").textContent =
  new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric"
  });

renderRecipes();
refreshEverything();

const startingPage = location.hash.replace("#", "");

if (["home", "planner", "recipes", "pantry", "shopping"].includes(startingPage)) {
  showPage(startingPage);
}