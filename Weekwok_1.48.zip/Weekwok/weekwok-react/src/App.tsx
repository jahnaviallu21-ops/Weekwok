import { useState } from 'react'
import './App.css'

function App() {
  const [activePage, setActivePage] = useState('home')

  const pages = [
    { id: 'home', icon: '⌂', label: 'Home' },
    { id: 'planner', icon: '▦', label: 'Meal Planner' },
    { id: 'recipes', icon: '✳', label: 'Recipes' },
    { id: 'pantry', icon: '◈', label: 'My Pantry' },
    { id: 'shopping', icon: '🛒', label: 'Shopping List' },
  ]

  return (
    <div className="app">

      <aside className="sidebar">
        <a className="brand">
          <span className="brand-icon">w.</span>
          <span>
            weekwok
            <small>THE ART OF PLANNING WELL</small>
          </span>
        </a>

        <div className="sidebar-label">WORKSPACE</div>

        <nav className="navigation">
          {pages.map((page) => (
            <button
              key={page.id}
              className={`nav-link ${activePage === page.id ? 'active' : ''}`}
              onClick={() => setActivePage(page.id)}
            >
              <span>{page.icon}</span>
              {page.label}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-message">
            <span>✳</span>
            <p>A little planning<br />goes a long way.</p>
            <small>MAKE EVERY MEAL COUNT.</small>
          </div>

          <div className="profile">
            <div className="profile-avatar">J</div>
            <div>
              <strong>My Kitchen</strong>
              <small>Personal workspace</small>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-content">

        <header className="topbar">
          <div>
            <span className="top-eyebrow">YOUR KITCHEN, IN GOOD ORDER</span>
            <p>{new Date().toDateString()}</p>
          </div>

          <div className="top-actions">
            <span className="status-indicator"></span>
            Kitchen is organised
          </div>
        </header>

        <section className="page active">
          {activePage === 'home' && (
            <div className="page-heading">
              <div>
                <span className="eyebrow">WELCOME TO WEEKWOK</span>
                <h1>Make room for <em>something delicious.</em></h1>
                <p>Your kitchen, beautifully organised.</p>
              </div>
            </div>
          )}

          {activePage === 'planner' && (
            <div className="page-heading">
              <h1>The weekly <em>table.</em></h1>
            </div>
          )}

          {activePage === 'recipes' && (
            <div className="page-heading">
              <h1>Made with <em>love.</em></h1>
            </div>
          )}

          {activePage === 'pantry' && (
            <div className="page-heading">
              <h1>My <em>pantry.</em></h1>
            </div>
          )}

          {activePage === 'shopping' && (
            <div className="page-heading">
              <h1>Gather the <em>good things.</em></h1>
            </div>
          )}
        </section>

      </main>
    </div>
  )
}

export default App